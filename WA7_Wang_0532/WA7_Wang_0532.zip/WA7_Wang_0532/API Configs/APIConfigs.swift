//
//  APIConfigs.swift
//  WA7_Wang_0532
//
//  Created by jocw on 10/27/24.
//

import Foundation

class APIConfigs {
    static let baseAuthURL = "http://apis.sakibnm.work:3000/api/auth/"
    static let baseNoteURL = "http://apis.sakibnm.work:3000/api/note/"
}
